{{/*
Chart-managed voice Secret (agent.voice.enabled).
*/}}
{{- define "agent-platform.voice.secret" -}}
{{- if .Values.agent.voice.enabled }}
{{- /*
  Chart-managed voice Secret (CV-1.1). Rendered whenever agent.voice.enabled.
  Holds the STT/TTS API KEY material so it never appears in plaintext Deployment
  env:
    - ELEVENLABS_API_KEY — TTS key (both providers), written only when set.
    - GROQ_API_KEY       — STT key, written only when provider=groq AND set.
  The admin Deployment sources these via secretKeyRef and the admin provisioner
  flows them into provisioned agent pods. Non-secret config (voiceId, the Whisper
  Service URL) is NOT stored here — it is injected as plain Deployment env.

  When voice is disabled this file renders nothing (no Secret). The Secret may be
  empty-data if voice is enabled with no keys set (e.g. provider=whisper with the
  in-pod Piper TTS fallback) — that is valid and intentional.
*/}}
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "agent-platform.voice.secretName" . }}
  labels:
    {{- include "agent-platform.agent.labels" . | nindent 4 }}
type: Opaque
data:
  {{- with .Values.agent.voice.elevenlabs.apiKey }}
  ELEVENLABS_API_KEY: {{ . | b64enc | quote }}
  {{- end }}
  {{- if eq .Values.agent.voice.provider "groq" }}
  {{- with .Values.agent.voice.groq.apiKey }}
  GROQ_API_KEY: {{ . | b64enc | quote }}
  {{- end }}
  {{- end }}
{{- end }}
{{- end }}
